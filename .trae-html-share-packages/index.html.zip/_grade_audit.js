/* 临时审计脚本：检查各级别单词难度是否符合（依据词条自带考试标签），可选降级明显错级的基础词 */
var fs = require('fs');
var APPLY = process.argv.indexOf('--apply') >= 0;
var path = '/workspace/index.html';
var s = fs.readFileSync(path, 'utf8');
var i = s.indexOf('window.WORDS_BANK');
var j = s.indexOf('\n', i);
var line = s.slice(i, j);
var body = line.replace(/^window\.WORDS_BANK\s*=\s*/, '');
var arr = JSON.parse(body.slice(0, body.lastIndexOf(']') + 1));

var tag = function (x) { return (x[7] || '').split('/').filter(Boolean); };

var bad = arr.filter(function (x) { return x[5] >= 6 && tag(x).indexOf('zk') >= 0; });
console.log('【中考基础词却被标为 Lv.6-10】共 ' + bad.length + ' 个：');
console.log(bad.map(function (x) { return x[0] + '(L' + x[5] + ')'; }).join(' '));

var lowGre = arr.filter(function (x) { var t = tag(x); return t.length && t.every(function (z) { return z === 'gre'; }) && x[5] <= 4; });
console.log('\n【仅 GRE 标签却标在 Lv.<=4】' + lowGre.length + ' 个：' + lowGre.map(function (x) { return x[0] + '(L' + x[5] + ')'; }).join(' '));

[4, 5].forEach(function (L) {
  var long = arr.filter(function (x) { return x[5] === L && x[0].replace(/[^a-z]/gi, '').length >= 12; });
  console.log('\n【Lv.' + L + ' 中长度 >=12】' + long.length + ' 个：' + long.slice(0, 25).map(function (x) { return x[0] + '[' + (x[7] || '-') + ']'; }).join(' '));
});

if (APPLY) {
  var advanced = ['cet4', 'cet6', 'ky', 'toefl', 'ielts', 'gre'];
  var c3 = 0, c4 = 0;
  arr.forEach(function (x) {
    if (x[5] >= 6 && tag(x).indexOf('zk') >= 0) {
      var high = tag(x).some(function (t) { return advanced.indexOf(t) >= 0; });
      x[5] = high ? 4 : 3;
      if (high) c4++; else c3++;
    }
  });
  fs.writeFileSync(path, s.slice(0, i) + 'window.WORDS_BANK=' + JSON.stringify(arr) + ';</script>' + s.slice(j));
  console.log('\n已写入：共 ' + (c3 + c4) + ' 个词条（-> Lv.3 的 ' + c3 + ' 个，-> Lv.4 的 ' + c4 + ' 个）');
}
